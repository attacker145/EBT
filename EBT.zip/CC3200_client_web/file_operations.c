//*****************************************************************************
//
// Application Name     -   File operations
//*****************************************************************************


//*****************************************************************************
//
//! \addtogroup filesystem_demo
//! @{
//
//*****************************************************************************
#include <stdlib.h>
#include <string.h>

// Simplelink includes
#include "simplelink.h"

//Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "rom.h"
#include "rom_map.h"
#include "interrupt.h"
#include "prcm.h"

//Common interface includes
#include "gpio_if.h"
#include "common.h"
#ifndef NOTERM
#include "uart_if.h"
#endif
#include "pinmux.h"


//#define APPLICATION_NAME        "FILE OPERATIONS"
//#define APPLICATION_VERSION     "1.1.1"

#define SL_MAX_FILE_SIZE        64L*1024L       /* 64KB file */
#define BUF_SIZE                2048
#define USER_FILE_NAME          "fs_demo.txt"

/* Application specific status/error codes */
typedef enum{
    // Choosing this number to avoid overlap w/ host-driver's error codes
    FILE_ALREADY_EXIST = -0x7D0,
    FILE_CLOSE_ERROR = FILE_ALREADY_EXIST - 1,
    FILE_NOT_MATCHED = FILE_CLOSE_ERROR - 1,
    FILE_OPEN_READ_FAILED = FILE_NOT_MATCHED - 1,
    FILE_OPEN_WRITE_FAILED = FILE_OPEN_READ_FAILED -1,
    FILE_READ_FAILED = FILE_OPEN_WRITE_FAILED - 1,
    FILE_WRITE_FAILED = FILE_READ_FAILED - 1,

    STATUS_CODE_MAX = -0xBB8
}e_AppStatusCodes;

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
unsigned char gaucCmpBuf[BUF_SIZE];
extern unsigned char gaucOldMacDonald; //unsigned char gaucOldMacDonald[4] write data to this array
/*
const unsigned char gaucOldMacDonald[] = "Old MacDonald had a farm,E-I-E-I-O, \
And on his farm he had a cow, \
E-I-E-I-O, \
With a moo-moo here, \
And a moo-moo there, \
Here a moo, there a moo, \
Everywhere a moo-moo. \
Old MacDonald had a farm, \
E-I-E-I-O. \
Old MacDonald had a farm, \
E-I-E-I-O, \
And on his farm he had a pig, \
E-I-E-I-O, \
With an oink-oink here, \
And an oink-oink there, \
Here an oink, there an oink, \
Everywhere an oink-oink. \
Old MacDonald had a farm, \
E-I-E-I-O. \
Old MacDonald had a farm, \
E-I-E-I-O, \
And on his farm he had a duck, \
E-I-E-I-O, \
With a quack-quack here, \
And a quack-quack there, \
Here a quack, there a quack, \
Everywhere a quack-quack. \
Old MacDonald had a farm, \
E-I-E-I-O. \
Old MacDonald had a farm, \
E-I-E-I-O, \
And on his farm he had a horse, \
E-I-E-I-O, \
With a neigh-neigh here, \
And a neigh-neigh there, \
Here a neigh, there a neigh, \
Everywhere a neigh-neigh. \
Old MacDonald had a farm, \
E-I-E-I-O. \
Old MacDonald had a farm, \
E-I-E-I-O, \
And on his farm he had a donkey, \
E-I-E-I-O, \
With a hee-haw here, \
And a hee-haw there, \
Here a hee, there a hee, \
Everywhere a hee-haw. \
Old MacDonald had a farm, \
E-I-E-I-O. \
Old MacDonald had a farm, \
E-I-E-I-O, \
And on his farm he had some chickens, \
E-I-E-I-O, \
With a cluck-cluck here, \
And a cluck-cluck there, \
Here a cluck, there a cluck, \
Everywhere a cluck-cluck. \
Old MacDonald had a farm, \
E-I-E-I-O.";*/

/*
 * open file for read or write from/to storage device

Parameters
[in]    pFileName   File Name buffer pointer
[in]    AccessModeAndMaxSize    Options: As described below
[in]    pToken  Reserved for future use. Use NULL for this field
[out]   pFileHandle Pointing on the file and used for read and write commands to the file
AccessModeAndMaxSize possible input
FS_MODE_OPEN_READ - Read a file
FS_MODE_OPEN_WRITE - Open for write for an existing file
FS_MODE_OPEN_CREATE(maxSizeInBytes,accessModeFlags) - Open for creating a new file. Max file size is defined in bytes.
For optimal FS size, use max size in 4K-512 bytes steps (e.g. 3584,7680,117760)
Several access modes bits can be combined together from SlFileOpenFlags_e enum

The syntax for SerFlash.open() therefore is something like this:



SerFlash.open("myfile.txt", FS_MODE_OPEN_READ);  // Open file for reading

SerFlash.open("myfile.txt", FS_MODE_OPEN_CREATE(1024, _FS_FILE_OPEN_FLAG_COMMIT));  // Create new file, allocated 1024 bytes to contain it

SerFlash.open("myfile.txt", FS_MODE_OPEN_WRITE);  // Open file for re-writing
 */
#define MAX_STRING_LENGTH    80
extern signed char cPassword[MAX_STRING_LENGTH+1];
extern signed char cSSID_NAME[MAX_STRING_LENGTH+1];

#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif

//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************

//*****************************************************************************
//
//!  This funtion includes the following steps:
//!  -open a user file for writing
//!  -write "Old MacDonalds" child song 37 times to get just below a 64KB file
//!  -close the user file
//!
//!  /param[out] ulToken : file token
//!  /param[out] lFileHandle : file handle
//!
//!  /return  0:Success, -ve: failure
//
//*****************************************************************************
long WriteFileToDevice(unsigned long *ulToken, long *lFileHandle, signed char* dat)
{
    long lRetVal = -1;
    //unsigned int i;
    //int iLoopCnt = 0;

    //
    //  create a user file
    //
    lRetVal = sl_FsOpen((unsigned char *)USER_FILE_NAME,
                FS_MODE_OPEN_CREATE(1024, \
                          _FS_FILE_OPEN_FLAG_COMMIT|_FS_FILE_PUBLIC_WRITE),
                        ulToken,
                        lFileHandle);
    if(lRetVal < 0)
    {
        UART_PRINT("\n\r Failed to open file\n\r");
        // File may already be created
        lRetVal = sl_FsClose(*lFileHandle, 0, 0, 0);
        ASSERT_ON_ERROR(lRetVal);
    }
    else
    {
        // close the user file
        lRetVal = sl_FsClose(*lFileHandle, 0, 0, 0);
        if (SL_RET_CODE_OK != lRetVal)
        {
            ASSERT_ON_ERROR(FILE_CLOSE_ERROR);
        }
    }

    //  open a user file for writing
    lRetVal = sl_FsOpen((unsigned char *)USER_FILE_NAME, FS_MODE_OPEN_WRITE, ulToken, lFileHandle);
    if(lRetVal < 0)
    {
        lRetVal = sl_FsClose(*lFileHandle, 0, 0, 0);
        ASSERT_ON_ERROR(FILE_OPEN_WRITE_FAILED);
    }else{
        Report("File Opened: %s\n",USER_FILE_NAME);
    }

    //lRetVal = sl_FsWrite(*lFileHandle,
    //          (unsigned int)(iLoopCnt * sizeof(gaucOldMacDonald)),
    //          (unsigned char *)gaucOldMacDonald, sizeof(gaucOldMacDonald));//cSSID_NAME
    lRetVal = sl_FsWrite(*lFileHandle, 0, (unsigned char *)dat, (_u32)100);//cSSID_NAME
    if (lRetVal < 0)
    {
        lRetVal = sl_FsClose(*lFileHandle, 0, 0, 0);
        ASSERT_ON_ERROR(FILE_WRITE_FAILED);
    }else{
            //Report("\n\rWrote to file HEX: ");
            //for (i = 0; i < 50; i++){
                //Report("%02X:", dat[i]);
            //}
    }

    // close the user file
    lRetVal = sl_FsClose(*lFileHandle, 0, 0, 0);
    if (SL_RET_CODE_OK != lRetVal)
    {
        ASSERT_ON_ERROR(FILE_CLOSE_ERROR);
    }else{
        Report("File close\n");
    }

    return SUCCESS;
}

//*****************************************************************************
//
//!  This funtion includes the following steps:
//!    -open the user file for reading
//!    -read the data and compare with the stored buffer
//!    -close the user file
//!
//!  /param[in] ulToken : file token
//!  /param[in] lFileHandle : file handle
//!
//!  /return 0: success, -ve:failure
//
//*****************************************************************************
long ReadFileFromDevice(unsigned long ulToken, long lFileHandle, signed char* dat)
{
    long lRetVal = -1;
    //unsigned int i;
    //int iLoopCnt = 0;

    // open a user file for reading
    lRetVal = sl_FsOpen((unsigned char *)USER_FILE_NAME, FS_MODE_OPEN_READ, &ulToken, &lFileHandle);
    if(lRetVal < 0)
    {
        lRetVal = sl_FsClose(lFileHandle, 0, 0, 0);
        Report("\n\r");
        ASSERT_ON_ERROR(FILE_OPEN_READ_FAILED);
    }
    // read the data and compare with the stored buffer
//    for (iLoopCnt = 0;
//            iLoopCnt < (SL_MAX_FILE_SIZE / sizeof(gaucOldMacDonald));
//            iLoopCnt++)
//    {
    //lRetVal = sl_FsRead(lFileHandle, (unsigned int)(iLoopCnt * sizeof(dat)), gaucCmpBuf, sizeof(dat));
    lRetVal = sl_FsRead(lFileHandle, 0, (unsigned char*) dat, (_u32)100);
    if ((lRetVal < 0) || (lRetVal != sizeof(dat)))
    {
        lRetVal = sl_FsClose(lFileHandle, 0, 0, 0);
        Report("\n\r");
        ASSERT_ON_ERROR(FILE_READ_FAILED);
    }
    //Report("\n\rRead from file HEX: ");
    //for (i = 0; i < 50; i++){
        //Report("%02X:", dat[i]);
    //}


        /*
        lRetVal = memcmp(gaucOldMacDonald,
                         gaucCmpBuf,
                         sizeof(gaucOldMacDonald));
        if (lRetVal != 0)
        {
            ASSERT_ON_ERROR(FILE_NOT_MATCHED);
        }*/
//    }

    //
    // close the user file
    //
    lRetVal = sl_FsClose(lFileHandle, 0, 0, 0);
    if (SL_RET_CODE_OK != lRetVal)
    {
        ASSERT_ON_ERROR(FILE_CLOSE_ERROR);
    }

    return SUCCESS;
}

//*****************************************************************************
//
//! \brief  the aim of this example code is to demonstrate File-system
//!          capabilities of the device.
//!         For simplicity, the serial flash is used as the device under test.
//!
//! \param  None
//!
//! \return none
//!
//! \note   Green LED is turned solid in case of success
//!         Red LED is turned solid in case of failure
//
//*****************************************************************************

void file_operations (void)
{
    long lRetVal;
    unsigned char policyVal;
    long lFileHandle;
    unsigned long ulToken;
    signed char dat [] = {0,0,0,0,0,0,0,0};
    signed char read_dat [] = {0,0,0,0,0,0,0,0};

#ifndef cloud
    //
    // Initializing the CC3200 networking layers
    //
    lRetVal = sl_Start(NULL, NULL, NULL);
    if(lRetVal < 0)
    {
    //    GPIO_IF_LedOn(MCU_RED_LED_GPIO);
        UART_PRINT("\n\r sl_Start failed");
        LOOP_FOREVER();
    }

    //
    // reset all network policies
    //
    lRetVal = sl_WlanPolicySet(  SL_POLICY_CONNECTION,
                    SL_CONNECTION_POLICY(0,0,0,0,0),
                    &policyVal,
                    1 /*PolicyValLen*/);
    if(lRetVal < 0)
    {
    //    GPIO_IF_LedOn(MCU_RED_LED_GPIO);
        UART_PRINT("\n\r sl_WlanPolicySet failed");
        LOOP_FOREVER();
    }
#endif

    if(WriteFileToDevice(&ulToken, &lFileHandle, dat) < 0)
    {
        //GPIO_IF_LedOn(MCU_RED_LED_GPIO);
        LOOP_FOREVER();
    }

    if(ReadFileFromDevice(ulToken, lFileHandle, read_dat) < 0)
    {
        //GPIO_IF_LedOn(MCU_RED_LED_GPIO);
         LOOP_FOREVER();
    }

    //
    // turn ON the green LED indicating success
    //
   // GPIO_IF_LedOn(MCU_GREEN_LED_GPIO);
    //lRetVal = sl_Stop(SL_STOP_TIMEOUT);

       //LOOP_FOREVER();

}
//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
